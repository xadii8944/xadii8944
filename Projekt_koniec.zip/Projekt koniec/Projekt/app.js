const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const db = require('./db') 

const app = express();
const port = 3000; // Set your desired port number
app.use(express.static('public'));
app.use(bodyParser.json());

// Endpoint to save data to MySQL
app.post('/update', (req, res) => {
    console.log(req.body)
  const { imie, nazwisko, data_urodzenia, email, hasło } = req.body; // Assuming the request body contains name and email fields
    if (!imie || !nazwisko || !data_urodzenia || !email || !hasło) {
      throw new Error('Czegoś brakuje');
    }

  // Perform the database query
  db.query('INSERT INTO uzytkownicy (imie, nazwisko, data_urodzenia, e_mail, haslo) VALUES (?, ?, ?, ?, ?)', [imie, nazwisko, data_urodzenia, email, hasło], (error, results) => {
    if (error) {
      console.error('Error saving data to MySQL:', error);
      res.status(500).json({ error: 'Error saving data to MySQL' });
    } else {
      console.log('Data saved to MySQL:', results);
      res.status(200).json({ message: 'Data saved to MySQL' });
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});